# `github.com/gobuffalo/envy` Stands on the Shoulders of Giants

`github.com/gobuffalo/envy` does not try to reinvent the wheel! Instead, it uses the already great wheels developed by the Go community and puts them all together in the best way possible. Without these giants this project would not be possible. Please make sure to check them out and thank them for all of their hard work.

Thank you to the following **GIANTS**:


* [github.com/gobuffalo/envy](https://godoc.org/github.com/gobuffalo/envy)

* [github.com/joho/godotenv](https://godoc.org/github.com/joho/godotenv)

* [github.com/rogpeppe/go-internal/modfile](https://godoc.org/github.com/rogpeppe/go-internal/modfile)

* [github.com/rogpeppe/go-internal/module](https://godoc.org/github.com/rogpeppe/go-internal/module)

* [github.com/rogpeppe/go-internal/semver](https://godoc.org/github.com/rogpeppe/go-internal/semver)
