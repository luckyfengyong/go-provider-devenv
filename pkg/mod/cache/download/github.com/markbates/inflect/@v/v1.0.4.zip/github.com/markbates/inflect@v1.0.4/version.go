package inflect

const Version = "v1.0.4"
